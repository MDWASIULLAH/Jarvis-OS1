"""
training/train_intents.py

Trains and evaluates the intent model, then writes it to
`app/brain/models/intent_model.json`.

    python -m training.train_intents

Held-out evaluation is printed every run and the script exits non-zero if
accuracy drops below the threshold, so a bad dataset change fails loudly
instead of silently degrading the assistant. `tests/test_brain_nlu.py` runs
the same evaluation in CI.
"""

from __future__ import annotations

import csv
import random
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))

from app.brain.nlu import MODEL_PATH, IntentModel  # noqa: E402
from training.build_dataset import OUTPUT, build  # noqa: E402

MIN_ACCURACY = 0.85


def load_rows() -> list[tuple[str, str]]:
    # Always rebuild. Reusing a stale CSV meant edits to templates.py or
    # paraphrases.py silently had no effect on the trained model, which is a
    # deeply confusing failure to debug.
    build()
    with OUTPUT.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        return [
            (row["text"], row["intent"])
            for row in reader
            if row.get("text") and row.get("intent")
        ]


def split(rows: list[tuple[str, str]], holdout: float = 0.2, seed: int = 11):
    """Stratified split so every intent appears in both halves."""
    grouped: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[row[1]].append(row)
    rng = random.Random(seed)
    train: list[tuple[str, str]] = []
    test: list[tuple[str, str]] = []
    for label, items in grouped.items():
        rng.shuffle(items)
        cut = max(1, int(len(items) * holdout)) if len(items) > 4 else 0
        test += items[:cut]
        train += items[cut:]
    rng.shuffle(train)
    return train, test


def evaluate(model: IntentModel, rows: list[tuple[str, str]]) -> tuple[float, dict]:
    correct = 0
    per_label_total: dict[str, int] = defaultdict(int)
    per_label_hit: dict[str, int] = defaultdict(int)
    for text, expected in rows:
        predicted, _, _ = model.predict(text)
        per_label_total[expected] += 1
        if predicted == expected:
            correct += 1
            per_label_hit[expected] += 1
    accuracy = correct / len(rows) if rows else 0.0
    per_label = {
        label: round(per_label_hit[label] / total, 3)
        for label, total in sorted(per_label_total.items())
    }
    return accuracy, per_label


def train_and_save(verbose: bool = True) -> tuple[IntentModel, float]:
    rows = load_rows()
    train_rows, test_rows = split(rows)
    model = IntentModel().train(train_rows)
    split_accuracy, per_label = evaluate(model, test_rows)

    # Ship a model trained on everything -- the split above exists to measure
    # generalisation, not to throw away 20% of the data in production.
    final = IntentModel().train(rows)
    final.save(MODEL_PATH)

    # The number that actually matters. A random split of template-generated
    # data shares templates between train and test, so it scores near 1.00 by
    # memorisation. `eval_set.py` is hand-written in phrasings and entities that
    # appear nowhere in the templates, so it measures real generalisation. It is
    # reported as the headline figure and it gates the exit code.
    holdout_accuracy = _score_holdout()

    if verbose:
        print(f"dataset       : {len(rows)} rows, {len(set(r[1] for r in rows))} intents")
        print(f"train / test  : {len(train_rows)} / {len(test_rows)}")
        print(f"features      : {final.core.feature_count}")
        print(f"split acc     : {split_accuracy:.3f}  (same-template split; inflated by design)")
        print(f"HELD-OUT acc  : {holdout_accuracy:.3f}  (hand-written unseen phrasings)")
        weak = {k: v for k, v in per_label.items() if v < 0.85}
        if weak:
            print("weak intents  :")
            for label, score in sorted(weak.items(), key=lambda kv: kv[1]):
                print(f"  {label:<26} {score:.2f}")
        size_kb = MODEL_PATH.stat().st_size / 1024
        print(f"saved         : {MODEL_PATH} ({size_kb:.0f} KB)")
    return final, holdout_accuracy


def _score_holdout() -> float:
    """Runs the full pipeline (rules + freshly saved model) over the eval set."""
    from app.brain.nlu import IntentAnalyzer
    from training import eval_set

    analyzer = IntentAnalyzer()
    rows = eval_set.rows()
    if not rows:
        return 0.0
    hits = sum(1 for text, expected in rows if analyzer.analyze(text).intent == expected)
    return hits / len(rows)


if __name__ == "__main__":
    _, score = train_and_save()
    if score < MIN_ACCURACY:
        print(f"FAIL: held-out accuracy {score:.3f} is below the {MIN_ACCURACY} threshold.")
        raise SystemExit(1)
    print("OK")
