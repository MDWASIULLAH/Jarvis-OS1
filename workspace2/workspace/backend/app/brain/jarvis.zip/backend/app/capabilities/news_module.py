"""
capabilities/news_module.py

Implements JARVIS Section 2.6 -- news & information. If a News API key is
configured, use it. Otherwise, fall back to a free, keyless Google News RSS
feed so "what's the news" works out of the box with zero signup -- upgraded
from the spec's plain "no API configured" apology to something actually useful.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Optional

import requests

RSS_FEEDS = {
    "top": "https://news.google.com/rss",
    "technology": "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY",
    "sports": "https://news.google.com/rss/headlines/section/topic/SPORTS",
    "business": "https://news.google.com/rss/headlines/section/topic/BUSINESS",
    "world": "https://news.google.com/rss/headlines/section/topic/WORLD",
}


@dataclass
class NewsItem:
    title: str
    source: str
    link: str


class NewsModule:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key

    def is_configured(self) -> bool:
        return bool(self.api_key)

    def headlines(self, topic: str = "top", limit: int = 5) -> list:
        if self.is_configured():
            return self._from_news_api(topic, limit)
        return self._from_rss(topic, limit)

    def _from_news_api(self, topic: str, limit: int) -> list:
        try:
            r = requests.get(
                "https://newsapi.org/v2/top-headlines",
                params={"category": topic, "apiKey": self.api_key, "pageSize": limit, "language": "en"},
                timeout=5,
            )
            r.raise_for_status()
            articles = r.json().get("articles", [])
            return [
                NewsItem(title=a["title"], source=a["source"]["name"], link=a["url"])
                for a in articles[:limit]
            ]
        except requests.RequestException:
            return self._from_rss(topic, limit)  # fail soft, don't error out

    def _from_rss(self, topic: str, limit: int) -> list:
        url = RSS_FEEDS.get(topic, RSS_FEEDS["top"])
        try:
            r = requests.get(url, timeout=5, headers={"User-Agent": "Mozilla/5.0"})
            r.raise_for_status()
            root = ET.fromstring(r.content)
            items = []
            for item in root.findall(".//item")[:limit]:
                title = item.findtext("title") or "Untitled"
                source_el = item.find("source")
                source = source_el.text if source_el is not None else "Google News"
                link = item.findtext("link") or ""
                items.append(NewsItem(title=title, source=source, link=link))
            return items
        except (requests.RequestException, ET.ParseError):
            return []

    def summarize(self, topic: str = "top", limit: int = 5) -> str:
        items = self.headlines(topic, limit)
        if not items:
            return (
                "I couldn't reach a news source just now -- I'll use cached "
                "headlines if I have any, or try again shortly."
            )
        lines = [f"{i + 1}. {it.title} ({it.source})" for i, it in enumerate(items)]
        header = "Here's what's happening" + (f" in {topic}" if topic != "top" else "") + ":"
        return header + "\n" + "\n".join(lines)
