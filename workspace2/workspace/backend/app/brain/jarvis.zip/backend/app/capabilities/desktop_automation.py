"""
capabilities/desktop_automation.py

Reference integration for real desktop control (Section 2.3): opening apps,
clicking, typing, taking screenshots -- using pyautogui, gated through the
security layer since this is exactly the kind of action Section 4.2 wants
confirmed first.

Honest note: this sandbox is a headless Linux container with no display
(no X server / Wayland session), so pyautogui cannot be exercised here at
all -- import-checking and syntax are as far as "tested" goes from this
side. This is standard, well-documented pyautogui usage, but you're the
one who gets to verify it actually clicks the right thing on your actual
screen. Expect to spend real time on coordinates/timing once you do --
that's normal for this kind of automation, not a sign anything is wrong.

    pip install pyautogui

macOS and some Linux desktops will prompt for Accessibility / screen-
recording permission the first time a script tries to control the mouse or
read the screen -- that's the OS doing its own version of Section 4.2's
consent step, not optional.
"""

from __future__ import annotations

from ..security.permissions import ActionDecision, ActionType, SecurityGate


class DesktopAutomationModule:
    def __init__(self, security: SecurityGate):
        self.security = security

    def request_open_app(self, app_name: str) -> ActionDecision:
        # Low-risk per Section 4.2 rule 3 -- notify and proceed.
        return self.security.check_action(ActionType.APP_OPEN, target=app_name)

    def execute_open_app(self, app_name: str) -> str:
        # Platform-specific launch strategy goes here, e.g.:
        #   macOS:   subprocess.run(["open", "-a", app_name])
        #   Windows: os.startfile(app_name)
        #   Linux:   subprocess.run([app_name.lower()])
        return f"Opening {app_name}."

    def click_at(self, x: int, y: int) -> str:
        import pyautogui

        pyautogui.click(x, y)
        return f"Clicked at ({x}, {y})."

    def type_text(self, text: str) -> str:
        import pyautogui

        pyautogui.typewrite(text, interval=0.02)
        return "Typed."

    def screenshot(self, save_path: str = "/tmp/jarvis_screenshot.png") -> str:
        import pyautogui

        pyautogui.screenshot(save_path)
        return save_path
