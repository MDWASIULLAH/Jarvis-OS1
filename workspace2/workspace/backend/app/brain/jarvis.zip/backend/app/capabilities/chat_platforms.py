"""
capabilities/chat_platforms.py

Telegram and Discord bot clients (Section 13 / chat-platform integration).
Both platforms let you create a bot for free in minutes with no business
verification -- Telegram via @BotFather in the app, Discord via
discord.com/developers. These are the right choice for a personal project
like this one.

WhatsApp is deliberately NOT included here: the official WhatsApp Business
API requires Meta business verification (not a quick signup), and the
unofficial alternatives (e.g. libraries that automate WhatsApp Web) run
against WhatsApp's Terms of Service and carry real risk of the account
getting banned. Telegram/Discord below get you the same "JARVIS messages me
on my phone" experience without that risk.

Honest note: api.telegram.org and discord.com aren't reachable from this
sandbox's network, so neither of these has been tested live -- both follow
each platform's official documented Bot API exactly, but you're the one who
gets to run them for real, with your own bot token.
"""

from __future__ import annotations

import requests


class TelegramClient:
    def __init__(self, bot_token: str):
        self.base_url = f"https://api.telegram.org/bot{bot_token}"

    def send_message(self, chat_id: str, text: str) -> bool:
        try:
            r = requests.post(f"{self.base_url}/sendMessage", json={"chat_id": chat_id, "text": text}, timeout=6)
            return r.ok
        except requests.RequestException:
            return False

    def get_updates(self, offset: int = None) -> list:
        try:
            params = {"timeout": 5}
            if offset is not None:
                params["offset"] = offset
            r = requests.get(f"{self.base_url}/getUpdates", params=params, timeout=8)
            r.raise_for_status()
            return r.json().get("result", [])
        except requests.RequestException:
            return []


class DiscordClient:
    def __init__(self, bot_token: str):
        self.headers = {"Authorization": f"Bot {bot_token}"}

    def send_message(self, channel_id: str, text: str) -> bool:
        try:
            r = requests.post(
                f"https://discord.com/api/v10/channels/{channel_id}/messages",
                headers=self.headers,
                json={"content": text},
                timeout=6,
            )
            return r.ok
        except requests.RequestException:
            return False
