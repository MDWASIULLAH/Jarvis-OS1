"""
connectors/registry.py

The catalog of external apps JARVIS can connect to.

Every entry here maps onto a capability module that already exists in
`app/capabilities/` and that already accepts its credentials by constructor
argument. Nothing in this catalog is aspirational: if an app is listed, the
code that uses its credentials is real, and `verify.py` proves the credentials
work by making an actual authenticated call to the provider.

Fields are declared as data rather than hardcoded into the UI so the frontend
can render any connector's form without knowing anything about that provider.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional


@dataclass(frozen=True)
class ConnectorField:
    """One input on a connector's form."""

    key: str
    label: str
    placeholder: str = ""
    # Secret values are write-only: they are stored encrypted and are never
    # sent back to the browser, only ever a masked preview.
    secret: bool = False
    required: bool = True
    help: str = ""
    kind: Literal["text", "password", "url", "email"] = "text"


@dataclass(frozen=True)
class ConnectorSpec:
    id: str
    name: str
    category: str
    summary: str
    # Where the user actually obtains the credential. Without this the form is
    # a dead end for anyone who does not already have a token in hand.
    docs_url: str
    fields: tuple[ConnectorField, ...]
    # Short note shown under the form, e.g. security caveats.
    note: str = ""


CATALOG: tuple[ConnectorSpec, ...] = (
    ConnectorSpec(
        id="gmail",
        name="Gmail",
        category="Email",
        summary="Send email that JARVIS drafts for you.",
        docs_url="https://support.google.com/accounts/answer/185833",
        note=(
            "Use a Google App Password, not your account password. Requires "
            "2-step verification on the account."
        ),
        fields=(
            ConnectorField(
                key="address",
                label="Gmail address",
                placeholder="you@gmail.com",
                kind="email",
                help="Mail is sent from this address.",
            ),
            ConnectorField(
                key="app_password",
                label="App password",
                placeholder="16-character app password",
                secret=True,
                kind="password",
            ),
        ),
    ),
    ConnectorSpec(
        id="github",
        name="GitHub",
        category="Developer",
        summary="Read repos, commits, and issues; higher rate limits.",
        docs_url="https://github.com/settings/tokens",
        note="A classic token with the `repo` scope reads private repos too.",
        fields=(
            ConnectorField(
                key="token",
                label="Personal access token",
                placeholder="ghp_…",
                secret=True,
                kind="password",
            ),
        ),
    ),
    ConnectorSpec(
        id="youtube",
        name="YouTube",
        category="Media",
        summary="Search videos and read channel details.",
        docs_url="https://console.cloud.google.com/apis/credentials",
        note="Enable the YouTube Data API v3 on the project first.",
        fields=(
            ConnectorField(
                key="api_key",
                label="API key",
                placeholder="AIza…",
                secret=True,
                kind="password",
            ),
        ),
    ),
    ConnectorSpec(
        id="slack",
        name="Slack",
        category="Messaging",
        summary="Post messages to a channel.",
        docs_url="https://api.slack.com/apps",
        note="Needs a bot token with `chat:write`.",
        fields=(
            ConnectorField(
                key="bot_token",
                label="Bot token",
                placeholder="xoxb-…",
                secret=True,
                kind="password",
            ),
            ConnectorField(
                key="default_channel",
                label="Default channel",
                placeholder="#general",
                required=False,
                help="Used when you don't name a channel.",
            ),
        ),
    ),
    ConnectorSpec(
        id="telegram",
        name="Telegram",
        category="Messaging",
        summary="Send and receive messages through a bot.",
        docs_url="https://core.telegram.org/bots#how-do-i-create-a-bot",
        note="Create a bot with @BotFather to get a token.",
        fields=(
            ConnectorField(
                key="bot_token",
                label="Bot token",
                placeholder="123456:ABC-DEF…",
                secret=True,
                kind="password",
            ),
            ConnectorField(
                key="chat_id",
                label="Default chat ID",
                placeholder="e.g. 123456789",
                required=False,
            ),
        ),
    ),
    ConnectorSpec(
        id="discord",
        name="Discord",
        category="Messaging",
        summary="Post messages to a Discord channel.",
        docs_url="https://discord.com/developers/applications",
        fields=(
            ConnectorField(
                key="bot_token",
                label="Bot token",
                placeholder="Bot token from the Developer Portal",
                secret=True,
                kind="password",
            ),
        ),
    ),
    ConnectorSpec(
        id="home_assistant",
        name="Home Assistant",
        category="Smart home",
        summary="Control lights, switches, and scenes.",
        docs_url="https://www.home-assistant.io/docs/authentication/#your-account-profile",
        note="Create a long-lived access token on your HA profile page.",
        fields=(
            ConnectorField(
                key="base_url",
                label="Base URL",
                placeholder="http://homeassistant.local:8123",
                kind="url",
            ),
            ConnectorField(
                key="token",
                label="Long-lived token",
                placeholder="eyJ…",
                secret=True,
                kind="password",
            ),
        ),
    ),
    ConnectorSpec(
        id="openweather",
        name="OpenWeatherMap",
        category="Data",
        summary="Richer forecasts than the built-in free source.",
        docs_url="https://home.openweathermap.org/api_keys",
        note="Weather already works without this, using Open-Meteo.",
        fields=(
            ConnectorField(
                key="api_key",
                label="API key",
                placeholder="OpenWeatherMap key",
                secret=True,
                kind="password",
            ),
        ),
    ),
    ConnectorSpec(
        id="newsapi",
        name="NewsAPI",
        category="Data",
        summary="Headlines by category and keyword.",
        docs_url="https://newsapi.org/register",
        note="News already works without this, using RSS feeds.",
        fields=(
            ConnectorField(
                key="api_key",
                label="API key",
                placeholder="NewsAPI key",
                secret=True,
                kind="password",
            ),
        ),
    ),
    ConnectorSpec(
        id="image_api",
        name="Image generation",
        category="AI",
        summary="Generate images from a prompt via an OpenAI-compatible endpoint.",
        docs_url="https://platform.openai.com/api-keys",
        fields=(
            ConnectorField(
                key="api_url",
                label="Endpoint URL",
                placeholder="https://api.openai.com/v1",
                kind="url",
            ),
            ConnectorField(
                key="api_key",
                label="API key",
                placeholder="sk-…",
                secret=True,
                kind="password",
            ),
            ConnectorField(
                key="model",
                label="Model",
                placeholder="gpt-image-1",
                required=False,
            ),
        ),
    ),
    ConnectorSpec(
        id="cloud_llm",
        name="Cloud LLM",
        category="AI",
        summary="Fall back to a hosted model when the local one is unavailable.",
        docs_url="https://platform.openai.com/api-keys",
        note="JARVIS prefers your local Ollama model and only uses this as a fallback.",
        fields=(
            ConnectorField(
                key="base_url",
                label="Base URL",
                placeholder="https://api.openai.com/v1",
                kind="url",
            ),
            ConnectorField(
                key="api_key",
                label="API key",
                placeholder="sk-…",
                secret=True,
                kind="password",
            ),
            ConnectorField(
                key="model",
                label="Model",
                placeholder="gpt-4o-mini",
                required=False,
            ),
        ),
    ),
)

_BY_ID = {spec.id: spec for spec in CATALOG}


def get_spec(connector_id: str) -> Optional[ConnectorSpec]:
    return _BY_ID.get(connector_id)


def spec_to_dict(spec: ConnectorSpec) -> dict:
    """Serialise a spec for the API. Never includes stored values."""
    return {
        "id": spec.id,
        "name": spec.name,
        "category": spec.category,
        "summary": spec.summary,
        "docs_url": spec.docs_url,
        "note": spec.note,
        "fields": [
            {
                "key": f.key,
                "label": f.label,
                "placeholder": f.placeholder,
                "secret": f.secret,
                "required": f.required,
                "help": f.help,
                "kind": f.kind,
            }
            for f in spec.fields
        ],
    }


def missing_required(spec: ConnectorSpec, values: dict) -> list[str]:
    """Required field keys absent from `values`, so callers can reject early."""
    return [
        f.key
        for f in spec.fields
        if f.required and not str(values.get(f.key, "") or "").strip()
    ]
