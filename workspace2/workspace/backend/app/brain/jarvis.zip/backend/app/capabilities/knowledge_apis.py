"""
capabilities/knowledge_apis.py

Free, keyless knowledge lookups:
- define()               via the Free Dictionary API
- quick_answer()         via DuckDuckGo's Instant Answer API
- search_stackexchange() via the Stack Exchange API (keyless, shared quota --
                          add an app key for a higher rate limit later)
"""

from __future__ import annotations

import requests


def define(word: str) -> str:
    try:
        r = requests.get(f"https://api.dictionaryapi.dev/api/v2/entries/en/{word}", timeout=5)
        if r.status_code == 404:
            return f"I couldn't find a dictionary entry for '{word}'."
        r.raise_for_status()
        entry = r.json()[0]
        meaning = entry["meanings"][0]
        part_of_speech = meaning["partOfSpeech"]
        definition = meaning["definitions"][0]["definition"]
        return f"{word} ({part_of_speech}): {definition}"
    except (requests.RequestException, KeyError, IndexError):
        return "The dictionary service isn't reachable right now -- try again shortly."


def quick_answer(query: str) -> str:
    try:
        r = requests.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            timeout=5,
        )
        r.raise_for_status()
        data = r.json()
        text = data.get("AbstractText") or data.get("Answer")
        if not text:
            return f"I didn't get a direct answer for '{query}' from the instant-answer API -- try a full web search instead."
        return text
    except requests.RequestException:
        return "The search service isn't reachable right now -- try again shortly."


def search_stackexchange(query: str, site: str = "stackoverflow", limit: int = 3) -> list:
    try:
        r = requests.get(
            "https://api.stackexchange.com/2.3/search/advanced",
            params={"q": query, "site": site, "sort": "relevance", "pagesize": limit},
            timeout=6,
        )
        r.raise_for_status()
        items = r.json().get("items", [])
        return [{"title": it["title"], "link": it["link"], "score": it["score"]} for it in items[:limit]]
    except (requests.RequestException, KeyError):
        return []
