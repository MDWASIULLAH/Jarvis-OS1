/* ============================================================
   JARVIS — Speech Recognition (STT Input)
   Microphone input, wake word, continuous listening
   ============================================================ */
'use strict';

const JARVIS_SPEECH = (() => {

  /* ----- State ----- */
  let recognition = null;
  let isListening = false;
  let isContinuousMode = false;
  let wakeWordEnabled = true;
  const WAKE_WORD = 'jarvis';
  const STOP_PHRASE = 'jarvis stop';

  /* Callbacks */
  let onResult = null;  // (transcript: string) => void
  let onStart = null;   // () => void
  let onStop = null;    // () => void
  let onError = null;   // (error: string) => void

  /* ----- Initialization ----- */
  function init(callbacks = {}) {
    onResult = callbacks.onResult || null;
    onStart = callbacks.onStart || null;
    onStop = callbacks.onStop || null;
    onError = callbacks.onError || null;

    // Load settings
    wakeWordEnabled = JARVIS_UTILS.storageGet('wakeWordEnabled', true);
    isContinuousMode = JARVIS_UTILS.storageGet('continuousListening', false);
  }

  /**
   * Check if Speech Recognition is available
   * @returns {boolean}
   */
  function isAvailable() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  }

  /* ----- Start Listening ----- */
  /**
   * Start speech recognition
   * @param {Object} [options={}]
   * @param {boolean} [options.continuous=false] - Keep listening after results
   * @param {string} [options.lang='en-US'] - Recognition language
   * @returns {boolean} True if started successfully
   */
  function startListening(options = {}) {
    if (!isAvailable()) {
      JARVIS_UTILS.showToast(
        'Voice recognition works best in Chrome or Edge',
        'warning'
      );
      if (onError) onError('not-supported');
      return false;
    }

    if (isListening) {
      stopListening();
      return false;
    }

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SR();

    // Configuration
    recognition.continuous = options.continuous || isContinuousMode;
    recognition.interimResults = true;
    recognition.lang = options.lang || JARVIS_UTILS.storageGet('speechLang', 'en-US');
    recognition.maxAlternatives = 1;

    // --- Events ---
    recognition.onstart = () => {
      isListening = true;

      // Update UI
      const micBtn = document.getElementById('micButton');
      if (micBtn) micBtn.classList.add('listening');

      const mode = document.getElementById('mode');
      if (mode) mode.textContent = 'QUANTUM ARRAY // LISTENING';

      JARVIS_RENDERER.pulse(1.0);

      if (onStart) onStart();
    };

    recognition.onresult = (event) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript) {
        const processed = processTranscript(finalTranscript.trim());
        if (processed) {
          if (onResult) onResult(processed);
        }
      }

      // Show interim results in command input
      if (interimTranscript) {
        const cmd = document.getElementById('command');
        if (cmd) cmd.value = interimTranscript;
      }
    };

    recognition.onend = () => {
      isListening = false;

      // Update UI
      const micBtn = document.getElementById('micButton');
      if (micBtn) micBtn.classList.remove('listening');

      const mode = document.getElementById('mode');
      if (mode && !JARVIS_VOICE.isSpeaking()) {
        mode.textContent = 'QUANTUM ARRAY // STANDBY';
      }

      if (onStop) onStop();

      // Auto-restart in continuous mode
      if (isContinuousMode && !recognition._manualStop) {
        setTimeout(() => {
          if (isContinuousMode) {
            startListening(options);
          }
        }, 300);
      }
    };

    recognition.onerror = (event) => {
      const errorMessages = {
        'not-allowed': 'Microphone permission denied. Please allow microphone access.',
        'no-speech': 'No speech detected. Try again.',
        'network': 'Network error. Voice recognition requires internet.',
        'aborted': 'Voice input cancelled.',
        'audio-capture': 'No microphone found. Check your device.',
        'service-not-allowed': 'Speech service not available.',
      };

      const msg = errorMessages[event.error] || 'Voice input error: ' + event.error;

      // Don't show toast for expected stops
      if (event.error !== 'aborted' && event.error !== 'no-speech') {
        JARVIS_UTILS.showToast(msg, 'error');
      }

      if (onError) onError(event.error);
    };

    // Start recognition
    try {
      recognition._manualStop = false;
      recognition.start();
      return true;
    } catch (err) {
      console.error('[JARVIS Speech] Failed to start:', err);
      JARVIS_UTILS.showToast('Failed to start voice recognition', 'error');
      return false;
    }
  }

  /* ----- Stop Listening ----- */
  /**
   * Stop speech recognition
   */
  function stopListening() {
    if (recognition) {
      recognition._manualStop = true;
      recognition.stop();
    }
    isListening = false;
  }

  /**
   * Cancel speech recognition without processing results
   */
  function cancel() {
    if (recognition) {
      recognition._manualStop = true;
      recognition.abort();
    }
    isListening = false;

    // Clear interim text
    const cmd = document.getElementById('command');
    if (cmd) cmd.value = '';
  }

  /* ----- Transcript Processing ----- */
  /**
   * Process transcript for wake words and commands
   * @param {string} text - Raw transcript
   * @returns {string|null} Processed text or null if filtered
   */
  function processTranscript(text) {
    const lower = text.toLowerCase();

    // Check for stop phrase
    if (lower.includes(STOP_PHRASE) || lower === 'stop') {
      JARVIS_VOICE.stop();
      JARVIS_UTILS.showToast('Voice interrupted', 'info');
      return null;
    }

    // Wake word handling
    if (wakeWordEnabled) {
      if (lower.startsWith(WAKE_WORD)) {
        // Remove wake word prefix
        let command = text.substring(WAKE_WORD.length).trim();
        // Remove leading punctuation from "Jarvis, do something"
        command = command.replace(/^[,!.?\s]+/, '');
        return command || null;
      }
      // If wake word is enabled but not detected, still process the command
      // (since user explicitly clicked the mic button)
    }

    return text;
  }

  /* ----- Settings ----- */
  /**
   * Enable/disable continuous listening mode
   * @param {boolean} enabled
   */
  function setContinuousMode(enabled) {
    isContinuousMode = enabled;
    JARVIS_UTILS.storageSet('continuousListening', enabled);
  }

  /**
   * Enable/disable wake word detection
   * @param {boolean} enabled
   */
  function setWakeWordEnabled(enabled) {
    wakeWordEnabled = enabled;
    JARVIS_UTILS.storageSet('wakeWordEnabled', enabled);
  }

  /**
   * Check if currently listening
   * @returns {boolean}
   */
  function getIsListening() {
    return isListening;
  }

  /* ----- Public API ----- */
  return {
    init,
    isAvailable,
    startListening,
    stopListening,
    cancel,
    setContinuousMode,
    setWakeWordEnabled,
    get isListening() { return isListening; },
    get isContinuous() { return isContinuousMode; },
  };

})();
