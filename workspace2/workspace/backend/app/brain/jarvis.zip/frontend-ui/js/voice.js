/* ============================================================
   JARVIS — Voice Synthesis (TTS Output)
   Handles speech output and synchronization with 3D renderer
   CRITICAL: Never blocks or freezes the render loop
   ============================================================ */
'use strict';

const JARVIS_VOICE = (() => {

  /* ----- State ----- */
  let speaking = false;
  let voiceQueue = [];
  let currentUtterance = null;
  let selectedVoice = null;
  let settings = {
    rate: 0.9,
    pitch: 0.72,
    volume: 0.9,
    voiceName: '',  // auto-select if empty
  };

  /* AudioContext for real-time amplitude analysis */
  let audioContext = null;
  let analyser = null;
  let amplitudeData = null;
  let amplitudeAnimId = null;

  /* ----- Initialization ----- */
  function init() {
    // Load saved voice settings
    const saved = JARVIS_UTILS.storageGet('voiceSettings', null);
    if (saved) {
      Object.assign(settings, saved);
    }

    // Wait for voices to load (Chrome loads async)
    if ('speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
        selectBestVoice();
      };
      selectBestVoice();
    }
  }

  /* ----- Voice Selection ----- */
  function selectBestVoice() {
    const voices = window.speechSynthesis?.getVoices() || [];
    if (voices.length === 0) return;

    // If user has a preferred voice, try to find it
    if (settings.voiceName) {
      const preferred = voices.find(v => v.name === settings.voiceName);
      if (preferred) {
        selectedVoice = preferred;
        return;
      }
    }

    // Auto-select: prefer English male voices for JARVIS character
    const englishVoices = voices.filter(v => v.lang.startsWith('en'));
    const maleKeywords = ['male', 'david', 'james', 'daniel', 'mark', 'guy'];
    const maleVoice = englishVoices.find(v =>
      maleKeywords.some(k => v.name.toLowerCase().includes(k))
    );

    if (maleVoice) {
      selectedVoice = maleVoice;
    } else if (englishVoices.length > 0) {
      selectedVoice = englishVoices[0];
    } else if (voices.length > 0) {
      selectedVoice = voices[0];
    }
  }

  /**
   * Get list of available voices
   * @returns {SpeechSynthesisVoice[]}
   */
  function getVoices() {
    return window.speechSynthesis?.getVoices() || [];
  }

  /**
   * Set the voice by name
   * @param {string} voiceName
   */
  function setVoice(voiceName) {
    settings.voiceName = voiceName;
    const voices = getVoices();
    selectedVoice = voices.find(v => v.name === voiceName) || selectedVoice;
    saveSettings();
  }

  /**
   * Update voice parameters
   * @param {{ rate?: number, pitch?: number, volume?: number }} params
   */
  function setParams(params) {
    if (params.rate !== undefined) settings.rate = params.rate;
    if (params.pitch !== undefined) settings.pitch = params.pitch;
    if (params.volume !== undefined) settings.volume = params.volume;
    saveSettings();
  }

  function saveSettings() {
    JARVIS_UTILS.storageSet('voiceSettings', settings);
  }

  /* ----- Speech Synthesis ----- */
  /**
   * Speak a message through JARVIS voice
   * Non-blocking — the render loop continues independently
   * @param {string} message - Text to speak
   * @param {boolean} [immediate=false] - If true, cancel current speech first
   * @returns {Promise<void>} Resolves when speech completes
   */
  function speak(message, immediate = false) {
    return new Promise((resolve, reject) => {
      if (!('speechSynthesis' in window)) {
        console.warn('[JARVIS Voice] Speech synthesis not supported');
        resolve();
        return;
      }

      // Strip HTML tags for speech
      const cleanText = message.replace(/<[^>]*>/g, '').trim();
      if (!cleanText) {
        resolve();
        return;
      }

      if (immediate) {
        stop();
      }

      const utterance = new SpeechSynthesisUtterance(cleanText);

      // Apply settings (preserved from original)
      utterance.rate = settings.rate;
      utterance.pitch = settings.pitch;
      utterance.volume = settings.volume;
      if (selectedVoice) utterance.voice = selectedVoice;

      // --- Event handlers (all non-blocking, never freeze render) ---
      utterance.onstart = () => {
        speaking = true;
        currentUtterance = utterance;
        // Tell renderer to enhance animation — NOT freeze it
        JARVIS_RENDERER.setVoiceIntensity(1.0);
        JARVIS_RENDERER.pulse(2.4);
        updateModeText('SPEAKING');
        startAmplitudeTracking();
      };

      utterance.onboundary = (e) => {
        if (e.name === 'word') {
          // Pulse energy on each word boundary
          JARVIS_RENDERER.pulse(1.3);
        }
      };

      utterance.onend = () => {
        speaking = false;
        currentUtterance = null;
        // Smoothly reduce voice intensity (renderer interpolates)
        JARVIS_RENDERER.setVoiceIntensity(0);
        updateModeText('STANDBY');
        stopAmplitudeTracking();
        resolve();

        // Process next in queue
        processQueue();
      };

      utterance.onerror = (e) => {
        speaking = false;
        currentUtterance = null;
        JARVIS_RENDERER.setVoiceIntensity(0);
        updateModeText('STANDBY');
        stopAmplitudeTracking();

        if (e.error !== 'interrupted' && e.error !== 'canceled') {
          console.warn('[JARVIS Voice] Speech error:', e.error);
        }
        resolve(); // Resolve even on error to not block
        processQueue();
      };

      // Queue or speak immediately
      if (speaking && !immediate) {
        voiceQueue.push(utterance);
      } else {
        window.speechSynthesis.speak(utterance);
      }
    });
  }

  /**
   * Process the voice queue
   */
  function processQueue() {
    if (voiceQueue.length > 0 && !speaking) {
      const next = voiceQueue.shift();
      window.speechSynthesis.speak(next);
    }
  }

  /**
   * Stop all speech immediately
   */
  function stop() {
    voiceQueue = [];
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    speaking = false;
    currentUtterance = null;
    JARVIS_RENDERER.setVoiceIntensity(0);
    updateModeText('STANDBY');
    stopAmplitudeTracking();
  }

  /**
   * Check if currently speaking
   * @returns {boolean}
   */
  function isSpeaking() {
    return speaking;
  }

  /* ----- Mode Text Update ----- */
  function updateModeText(status) {
    const mode = document.getElementById('mode');
    if (mode) {
      mode.textContent = 'QUANTUM ARRAY // ' + status;
    }
  }

  /* ----- Amplitude Tracking (for real-time voice reactivity) ----- */
  function startAmplitudeTracking() {
    // Use a simple oscillation-based amplitude simulation
    // since SpeechSynthesis doesn't provide audio stream access
    if (amplitudeAnimId) return;

    function trackAmplitude() {
      if (!speaking) {
        JARVIS_RENDERER.setVoiceAmplitude(0);
        return;
      }

      // Simulate voice amplitude with sine waves for natural feel
      const t = performance.now() / 1000;
      const amp = 0.4 +
        Math.abs(Math.sin(t * 6.5)) * 0.3 +
        Math.abs(Math.sin(t * 11.2)) * 0.15 +
        Math.abs(Math.sin(t * 2.8)) * 0.15;

      JARVIS_RENDERER.setVoiceAmplitude(Math.min(1, amp));
      amplitudeAnimId = requestAnimationFrame(trackAmplitude);
    }

    trackAmplitude();
  }

  function stopAmplitudeTracking() {
    if (amplitudeAnimId) {
      cancelAnimationFrame(amplitudeAnimId);
      amplitudeAnimId = null;
    }
    JARVIS_RENDERER.setVoiceAmplitude(0);
  }

  /* ----- Public API ----- */
  return {
    init,
    speak,
    stop,
    isSpeaking,
    getVoices,
    setVoice,
    setParams,
    get settings() { return { ...settings }; },
  };

})();
